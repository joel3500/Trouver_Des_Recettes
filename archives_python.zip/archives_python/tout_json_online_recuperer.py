
# from recuperer_edamam_JSON import *           # abonnement mentuel obligatoirement payant, donc je laisse tomber

# from recuperer_recipe_puppy_JSON import *

# from recuperer_spoonacular_JSON import *        # J'ai fait la demande. J'attends toujours à ce qu'on me reponde pour m'accorder une clé

# from recuperer_the_meal_db_JSON import *      # Majoritairement en Anglais, donc je laisse tomber

def tout_json_online_recuperer() :

    print("===============================================================================")
    print("|      Chercher les informations des JSON online pour produire des JSON        |")
    print("===============================================================================")

    #recuperer_edamam_JSON()

    #recuperer_recipe_puppy_JSON()

    #recuperer_spoonacular_JSON()

    #recuperer_the_meal_db_JSON()